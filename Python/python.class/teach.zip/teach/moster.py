

class Moster():

	pass


class Moster1(Moster):
	pass

class Moster2(Moster):
	pass



